import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

/*
  Generated class for the DataProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
// Generate Fake Datas for the Userslist
@Injectable()
export class DataProvider {
  public available_items: any[];
  public available_items_for_search: any[];
  public my_items:any[]=[];
  public my_items_for_search: any[]=[];
  public current_num:number=0;
  public static max: number=3;
  constructor() {
    console.log('Hello DataProvider Provider');
    this.available_items = [
      { name: "Cable", mine: false},
      { name: "Beamer", mine: false},
      { name: "TV", mine: false},
      { name: "Pen", mine: false},
      { name: "Book", mine: false},
      
    ];
    this.available_items_for_search=this.available_items;
  }

}
