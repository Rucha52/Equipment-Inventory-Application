import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, MenuController } from 'ionic-angular';
import { SigninPage } from '../signin/signin';
import { TabsPage } from '../tabs/tabs';
import { SignupPage } from '../signup/signup';

/**
 * Generated class for the MenuPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-menu',
  templateUrl: 'menu.html',
})
export class MenuPage {

  @ViewChild('content') childNavCtrl: NavController;
  public signinPage:typeof SigninPage;
  public tabsPage:typeof TabsPage;
  public signupPage:typeof SignupPage;

  constructor(public navCtrl: NavController, public navParams: NavParams, private menuCtrl: MenuController) {
    this.signinPage=SigninPage;
    this.signupPage=SignupPage;
    this.tabsPage=TabsPage;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MenuPage');
  }
  onLoad(page: any){
    this.childNavCtrl.setRoot(page);
    this.menuCtrl.close();
  }

}
