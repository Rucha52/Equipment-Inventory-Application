import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { DataProvider } from '../../providers/data/data';

/**
 * Generated class for the ItemsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-items',
  templateUrl: 'items.html',
})
export class ItemsPage {

  public myInput : String;
  public my_items:any[];
  public my_items_for_search: any[]=[];
    
  constructor(public navCtrl: NavController, public navParams: NavParams, public data:DataProvider) {
    this.my_items=data.my_items;
    this.my_items_for_search=data.my_items;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ItemsPage');
  }

  updateList(event){
    console.log("test");
    console.log(this.myInput);

    let temp: any[]=[];
    this.my_items_for_search.forEach(element =>{
      if(element.name==this.myInput){
        temp.push(element);
      }
      });
      this.my_items=temp;

      if(this.myInput==""){
        this.my_items=this.my_items_for_search;
      }


    

  }

}
