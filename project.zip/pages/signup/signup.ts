import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { NgForm } from '@angular/forms';
import { AuthService } from "../../services/auth";

/**
 * Generated class for the SignupPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-signup',
  templateUrl: 'signup.html',
})
export class SignupPage {
  // Inject the auth.Service
  constructor(private  authService: AuthService) {}

  onSignup(form: NgForm) {
      this.authService.signup(form.value.email, form.value.password)
        .then(data => console.log(data))
       .catch(error => console.log(error));
    }
  }


