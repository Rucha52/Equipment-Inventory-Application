import firebase from 'firebase';

export class AuthService {
    // Returns the result of the request
    signup(email: string, password: string){
        return firebase.auth().createUserWithEmailAndPassword(email, password);
    }
}